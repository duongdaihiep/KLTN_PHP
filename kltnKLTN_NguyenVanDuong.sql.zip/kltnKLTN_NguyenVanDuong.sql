-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 01, 2024 at 10:23 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `kltn`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `AttendanceID` int(11) NOT NULL auto_increment,
  `EmployeeID` int(11) default NULL,
  `Date` date NOT NULL,
  `CheckInTime` datetime default NULL,
  `CheckOutTime` datetime default NULL,
  `StatusCheckIn` varchar(50) default NULL,
  `StatusCheckOut` varchar(50) default NULL,
  `imageIN` varchar(255) default NULL,
  `imageOUT` varchar(255) default NULL,
  `locationIN` varchar(255) default NULL,
  `locationOUT` varchar(255) default NULL,
  PRIMARY KEY  (`AttendanceID`),
  KEY `EmployeeID` (`EmployeeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`AttendanceID`, `EmployeeID`, `Date`, `CheckInTime`, `CheckOutTime`, `StatusCheckIn`, `StatusCheckOut`, `imageIN`, `imageOUT`, `locationIN`, `locationOUT`) VALUES
(6, 1, '2024-10-01', '2024-10-01 08:00:00', '2024-10-01 17:00:00', 'Approved', 'Approved', 'image1_in.jpg', 'image1_out.jpg', 'Location A', 'Location A'),
(7, 1, '2024-10-02', '2024-10-02 08:05:00', '2024-10-02 17:10:00', 'Approved', 'Approved', 'image2_in.jpg', 'image2_out.jpg', 'Location A', 'Location A'),
(8, 2, '2024-10-01', '2024-10-01 08:10:00', '2024-10-01 17:05:00', 'approved', 'approved', 'image3_in.jpg', 'image3_out.jpg', 'Location B', 'Location B'),
(9, 2, '2024-10-02', '2024-10-02 08:15:00', '2024-10-02 17:15:00', 'Approved', 'Approved', 'image4_in.jpg', 'image4_out.jpg', 'Location B', 'Location B'),
(10, 3, '2024-10-01', '2024-10-01 08:20:00', '2024-10-01 17:20:00', 'Approved', 'Approved', 'image5_in.jpg', 'image5_out.jpg', 'Location C', 'Location C'),
(11, 3, '2024-10-02', '2024-10-02 08:25:00', '2024-10-02 17:25:00', 'Approved', 'soon', 'image6_in.jpg', 'image6_out.jpg', 'Location C', 'Location C'),
(12, 1, '2024-10-03', '2024-10-03 08:30:00', '2024-10-03 17:30:00', 'Approved', 'Approved', 'image7_in.jpg', 'image7_out.jpg', 'Location A', 'Location A'),
(13, 2, '2024-10-03', '2024-10-03 08:35:00', '2024-10-03 17:35:00', 'Approved', 'Approved', 'image8_in.jpg', 'image8_out.jpg', 'Location B', 'Location B'),
(14, 3, '2024-10-03', '2024-10-03 08:40:00', '2024-10-03 17:40:00', 'Approved', 'Approved', 'image9_in.jpg', 'image9_out.jpg', 'Location C', 'Location C'),
(15, 1, '2024-10-04', '2024-10-04 08:45:00', '2024-10-04 17:45:00', 'Approved', 'Approved', 'image10_in.jpg', 'image10_out.jpg', 'Location A', 'Location A');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `DepartmentID` int(11) NOT NULL auto_increment,
  `DepartmentName` varchar(100) NOT NULL,
  PRIMARY KEY  (`DepartmentID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`DepartmentID`, `DepartmentName`) VALUES
(1, 'Human Resources');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `EmployeeID` int(11) NOT NULL auto_increment,
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Email` varchar(100) default NULL,
  `Phone` varchar(15) default NULL,
  `Position` varchar(100) default NULL,
  `HireDate` date default NULL,
  `DepartmentID` int(11) default NULL,
  PRIMARY KEY  (`EmployeeID`),
  KEY `DepartmentID` (`DepartmentID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`EmployeeID`, `FirstName`, `LastName`, `Email`, `Phone`, `Position`, `HireDate`, `DepartmentID`) VALUES
(1, 'Admin', 'User', 'admin@example.com', '01234567890', 'Admin', '2024-10-18', 1),
(2, 'Admin', 'User', 'ngocduonghtk@gmail.comsfdfgg', '0869217942', 'Administrator', '0000-00-00', NULL),
(3, 'Staff', 'User', NULL, NULL, 'Staff', NULL, NULL),
(5, 'NGUYEN VAN', 'DUONG', 'ngocduonghtk@gmail.com', '0869217942', 'Nhân viên', '2024-10-31', NULL),
(6, 'NGUYEN VAN', 'DUONG', 'ngocduonghtk@gmail.com', '0869217942', 'Nhân viên', '2024-10-31', NULL),
(7, 'Qu?n lý', 'User', 'ngocduonghtk@gmail.com', '0869217942', '', '2024-11-02', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `leaverequests`
--

CREATE TABLE `leaverequests` (
  `LeaveRequestID` int(11) NOT NULL auto_increment,
  `EmployeeID` int(11) default NULL,
  `StartDate` date NOT NULL,
  `EndDate` date NOT NULL,
  `Reason` text character set utf8,
  `Status` varchar(50) default NULL,
  PRIMARY KEY  (`LeaveRequestID`),
  KEY `EmployeeID` (`EmployeeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `leaverequests`
--

INSERT INTO `leaverequests` (`LeaveRequestID`, `EmployeeID`, `StartDate`, `EndDate`, `Reason`, `Status`) VALUES
(1, 3, '2024-10-26', '2024-10-27', 'csdfsdgdsg', 'Pending'),
(2, 3, '2024-10-26', '2024-10-27', 'csdfsdgdsg', 'Pending'),
(3, 3, '2024-10-26', '2024-10-27', 'csdfsdgdsg', 'Pending'),
(4, 3, '2024-10-26', '2024-10-27', 'csdfsdgdsg', 'Pending'),
(5, 3, '2024-10-31', '2024-11-01', '123', 'Refuse'),
(6, 3, '2024-10-31', '2024-11-01', 'bệnh', 'approved'),
(7, 3, '2024-10-31', '2024-10-31', 'chăm con ốm', 'approved');

-- --------------------------------------------------------

--
-- Table structure for table `salaries`
--

CREATE TABLE `salaries` (
  `SalaryID` int(11) NOT NULL auto_increment,
  `EmployeeID` int(11) default NULL,
  `BasicSalary` decimal(10,2) NOT NULL,
  `Bonus` decimal(10,2) default NULL,
  `Deductions` decimal(10,2) default NULL,
  `NetSalary` decimal(10,2) default NULL,
  `AdvanceSalary` decimal(10,2) default NULL,
  `PayDate` date default NULL,
  PRIMARY KEY  (`SalaryID`),
  KEY `EmployeeID` (`EmployeeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `salaries`
--

INSERT INTO `salaries` (`SalaryID`, `EmployeeID`, `BasicSalary`, `Bonus`, `Deductions`, `NetSalary`, `AdvanceSalary`, `PayDate`) VALUES
(9, 1, '10000000.00', '1000000.00', '500000.00', '9500000.00', '500000.00', '2024-10-15'),
(10, 2, '12000000.00', '1500000.00', '700000.00', '11300000.00', '700000.00', '2024-10-15'),
(11, 3, '11000000.00', '1200000.00', '600000.00', '10400000.00', '600000.00', '2024-10-15');

-- --------------------------------------------------------

--
-- Table structure for table `salaryrequests`
--

CREATE TABLE `salaryrequests` (
  `SalaryRequestID` int(11) NOT NULL auto_increment,
  `EmployeeID` int(11) default NULL,
  `RequestDate` date NOT NULL,
  `AmountRequested` decimal(10,2) default NULL,
  `Reason` text,
  `Status` varchar(50) default NULL,
  PRIMARY KEY  (`SalaryRequestID`),
  KEY `EmployeeID` (`EmployeeID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `salaryrequests`
--


-- --------------------------------------------------------

--
-- Table structure for table `schedules`
--

CREATE TABLE `schedules` (
  `ScheduleID` int(11) NOT NULL auto_increment,
  `EmployeeID` int(11) default NULL,
  `WorkDate` date default NULL,
  `StartTime` time default NULL,
  `EndTime` time default NULL,
  PRIMARY KEY  (`ScheduleID`),
  KEY `EmployeeID` (`EmployeeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `schedules`
--

INSERT INTO `schedules` (`ScheduleID`, `EmployeeID`, `WorkDate`, `StartTime`, `EndTime`) VALUES
(1, 1, '2024-11-01', '07:00:00', '17:00:00'),
(2, 1, '2024-11-02', '07:00:00', '17:00:00'),
(3, 1, '2024-11-03', '07:00:00', '17:00:00'),
(4, 1, '2024-11-04', '07:00:00', '17:00:00'),
(5, 1, '2024-11-05', '07:00:00', '17:00:00'),
(6, 1, '2024-11-06', '07:00:00', '17:00:00'),
(7, 1, '2024-11-07', '07:00:00', '17:00:00'),
(8, 1, '2024-11-08', '07:00:00', '17:00:00'),
(9, 1, '2024-11-09', '07:00:00', '17:00:00'),
(10, 1, '2024-11-10', '07:00:00', '17:00:00'),
(11, 1, '2024-11-11', '07:00:00', '17:00:00'),
(12, 1, '2024-11-12', '07:00:00', '17:00:00'),
(13, 1, '2024-11-13', '07:00:00', '17:00:00'),
(14, 1, '2024-11-14', '07:00:00', '17:00:00'),
(15, 1, '2024-11-15', '07:00:00', '17:00:00'),
(16, 1, '2024-11-16', '07:00:00', '17:00:00'),
(17, 1, '2024-11-17', '07:00:00', '17:00:00'),
(18, 1, '2024-11-18', '07:00:00', '17:00:00'),
(19, 1, '2024-11-19', '07:00:00', '17:00:00'),
(20, 1, '2024-11-20', '07:00:00', '17:00:00'),
(21, 1, '2024-11-21', '07:00:00', '17:00:00'),
(22, 1, '2024-11-22', '07:00:00', '17:00:00'),
(23, 1, '2024-11-23', '07:00:00', '17:00:00'),
(24, 1, '2024-11-24', '07:00:00', '17:00:00'),
(25, 1, '2024-11-25', '07:00:00', '17:00:00'),
(26, 1, '2024-11-26', '07:00:00', '17:00:00'),
(27, 1, '2024-11-27', '07:00:00', '17:00:00'),
(28, 1, '2024-11-28', '07:00:00', '17:00:00'),
(29, 1, '2024-11-29', '07:00:00', '17:00:00'),
(30, 1, '2024-11-30', '07:00:00', '17:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` int(11) NOT NULL auto_increment,
  `Username` varchar(50) NOT NULL,
  `PasswordHash` varchar(255) NOT NULL,
  `Role` varchar(50) NOT NULL,
  `EmployeeID` int(11) default NULL,
  `Status` varchar(50) default NULL,
  PRIMARY KEY  (`UserID`),
  UNIQUE KEY `Username` (`Username`),
  KEY `EmployeeID` (`EmployeeID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `Username`, `PasswordHash`, `Role`, `EmployeeID`, `Status`) VALUES
(2, 'testuser', '482c811da5d5b4bc6d497ffa98491e38', 'admin', 1, 'active'),
(3, 'adminuser', '482c811da5d5b4bc6d497ffa98491e38', 'admin', 2, 'active'),
(4, 'staffuser', '482c811da5d5b4bc6d497ffa98491e38', 'staff', 3, 'active'),
(11, 'duongdaihiep32', '482c811da5d5b4bc6d497ffa98491e38', 'staff', 5, 'Lock'),
(12, 'manageruser', '482c811da5d5b4bc6d497ffa98491e38', 'manager', 7, 'active');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`);

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `employees_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `departments` (`DepartmentID`);

--
-- Constraints for table `leaverequests`
--
ALTER TABLE `leaverequests`
  ADD CONSTRAINT `leaverequests_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`);

--
-- Constraints for table `salaries`
--
ALTER TABLE `salaries`
  ADD CONSTRAINT `salaries_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`);

--
-- Constraints for table `salaryrequests`
--
ALTER TABLE `salaryrequests`
  ADD CONSTRAINT `salaryrequests_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`);

--
-- Constraints for table `schedules`
--
ALTER TABLE `schedules`
  ADD CONSTRAINT `schedules_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`EmployeeID`) REFERENCES `employees` (`EmployeeID`);
